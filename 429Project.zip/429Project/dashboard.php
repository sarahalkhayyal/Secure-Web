<?php
require 'config.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['comment'] = $_POST['comment'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
    <p>This is your dashboard.</p>

    <form method="POST">
        <label for="comment">Leave a comment:</label><br>
        <textarea name="comment" rows="4" cols="50"></textarea><br>
        <input type="submit" value="Submit">
    </form>

    <h3>Recent Comment:</h3>

    <!-- --- VULNERABLE CODE START (No escaping, XSS risk) --- -->
    <?php
    if (isset($_SESSION['comment'])) {
        echo $_SESSION['comment']; // Vulnerable: renders HTML/JS
    }
    ?>
    
    <!-- --- VULNERABLE CODE END --- -->



    <!-- --- MITIGATION: Escape user input --- 
    <?php

    if (isset($_SESSION['comment'])) {
        echo htmlspecialchars($_SESSION['comment']);
    }
    
    ?>
    -->

    <br><br>
    <a href="logout.php">Logout</a>
</body>
</html>
