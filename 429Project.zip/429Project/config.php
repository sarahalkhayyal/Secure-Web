<?php
// --- Enforce HTTPS ---
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header("Location: https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit;
}

// MySQL connection for InfinityFree
$host = 'sql101.infinityfree.com';
$user = 'if0_38940288';
$password = 'Sarahhost123'; 
$db = 'if0_38940288_Online_Event_Booking';
$port = 3306;

$conn = new mysqli($host, $user, $password, $db, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect helper
function redirect($url)
{
    header("Location: $url");
    exit();
}

// Login check
function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

// Admin check
function isAdmin()
{
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}
?>
