<?php
session_start();

// Role-Based Access Control
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

/*
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    echo "Access denied. You do not have permission to view this page.";
    exit;
}
*/

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="style1.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            text-align: center;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 800px;
        }

        h1 {
            font-size: 3rem;
            color: #333;
        }

        .welcome-message {
            font-size: 1.5rem;
            color: #555;
            margin-bottom: 30px;
        }

        .confidential-info {
            font-size: 1.25rem;
            font-weight: bold;
            color: #e74c3c;
            margin-top: 50px;
        }

        a {
            text-decoration: none;
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        a:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Admin Page</h1>
    <div class="welcome-message">
        Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
    </div>

    <div class="confidential-info">
        CONFIDENTIAL INFORMATION HERE
    </div>

    <br><br>
    <a href="logout.php">Logout</a>
</div>

</body>
</html>